<?php
#Les champs entre /**/ sont � compl�ter.

$email=$_POST ['email'];     //extraction des variables du tableau _POST
$newsletter=$_POST ['newsletter'];

//connexion � mysql
$host="localhost"/*"ip de la base de donn�es"*/;
$account="root"/*"identifiant"*/;
$password=""/*"mot de passe"*/;
$dbname="newsletter"/*"nom de la base de donn�es"*/;
$connect=mysql_connect($host,$account,$password);
$db=mysql_select_db($dbname,$connect);

if ($newsletter==inscription)
{
$sql=/*"INSERT INTO nom de la table (email) VALUES ('$email')"*/;     //insertion de l'email dans la base de donn�es
$result=mysql_query($sql,$connect);
$disconnect=mysql_close($connect);     //d�connexion de la base de donn�es
header (/*"Location: page de redirection"*/);
}
else if ($newsletter==desinscription)
{
$sql=/*"DELETE FROM nom de la table WHERE email ='$email'"*/;     //suppression de l'email dans la base de donn�es
$result=mysql_query($sql,$connect);
$disconnect=mysql_close($connect);     //d�connexion de la base de donn�es
header (/*"Location: page de redirection"*/);
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Document sans titre</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

</body>
</html>
