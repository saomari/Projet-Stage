<?php session_start(); ?>
<!DOCTYPE html>
<?php
   try
{
 $bdd = new PDO('mysql:host=localhost;dbname=fpc', 'root', '');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}

if(isset($_POST['ok'])  and  isset($_POST['password']) and isset($_POST['login']))
{

extract($_POST);
$req = $bdd->prepare('SELECT * FROM candidat where login=? and mdp=?');
$req->execute(array($login,$password));
if(isset($_SESSION['login1']))
 unset($_SESSION['login1']);
 if(isset($_SESSION['mdp']))
 unset($_SESSION['mdp']);
 
 $_SESSION['login1']=$login;
$_SESSION['mdp1']=$password;

$b=true;
while ($donnees = $req->fetch())
{
    if($donnees['login']==$login and $donnees['mdp']==$password)  
     {
	
	       $b=false;
		   $req->closeCursor();
		   ?> <script>  self.location.href='candidat.php'; </script> <?php
	 }    
}
if($b==true)
{

     $req = $bdd->prepare('SELECT * FROM administrateur where login=? and mdp=?');
     $req->execute(array($login,$password));
while ($donnees = $req->fetch())
{
    if($donnees['login']==$login and $donnees['mdp']==$password)  
     {
	       $b=false;
		   $req->closeCursor();
		   ?> <script>  self.location.href='admin.php'; </script> <?php
	 }  	 
}
}

if($b==true)
{
   $req->closeCursor();
   ?> <script>  alert("vous avez saissiser un login ou un mot de passe incorect"); </script> <?php
}


}

?>
<head>
    
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
    <title>Licences</title>

    
	
	
	<meta charset="utf-8" />
	      <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
 
		<link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.14/themes/base/jquery-ui.css" type="text/css" media="all" />
		<link rel="stylesheet" href="http://static.jquery.com/ui/css/demo-docs-theme/ui.theme.css" type="text/css" media="all" />
		<link rel="stylesheet" href="styles/styleinscription.css" />
		<link rel="stylesheet" href="styles/styleindex.css" type="text/css" media="screen" />
		
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js" type="text/javascript"></script>
		<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.14/jquery-ui.min.js" type="text/javascript"></script>
		<script type="text/javascript" language="Javascript" src="scripts/jqueryins.js" ></script>
		<?php if(!empty($_POST)) {  ?>
		<script src="scripts/js1.js"></script>
		<?php } ?>
		<script src="scripts/js2.js"></script>
		<script src="scripts/cal.js"></script>
		<script src="scripts/cale.js"></script>
		<script language="JavaScript" src="scripts/gen_validatorv31.js" type="text/javascript"></script>
		<link rel="stylesheet" href="styles/stylecontact.css" />
    <script type="text/javascript" language="Javascript" src="scripts/jquerycon.js" ></script>
	<?php if(!empty($_POST)) { ?>
    <script src="scripts/java.js"></script>
	<?php } ?>
	<script src="scripts/java2.js"></script>
		
</head>
<body>

<div id="art-page-background-simple-gradient">
        <div id="art-page-background-gradient"></div>
    </div>
    <div id="art-page-background-glare">
        <div id="art-page-background-glare-image"></div>
    </div>
    <div id="art-main">
        <div class="art-sheet">
            <div class="art-sheet-tl"></div>
            <div class="art-sheet-tr"></div>
            <div class="art-sheet-bl"></div>
            <div class="art-sheet-br"></div>
            <div class="art-sheet-tc"></div>
            <div class="art-sheet-bc"></div>
            <div class="art-sheet-cl"></div>
            <div class="art-sheet-cr"></div>
            <div class="art-sheet-cc"></div>
            <div class="art-sheet-body">
                <div class="art-header">
                    <div class="art-header-jpeg"></div>
						<div><img src="images/logo.png"></div>
					<div class="art-logo">
                         <h1 id="name-text" class="art-logo-name"><a href="index.php">L'université de Bordeaux</a></h1>
                        <div id="slogan-text" class="art-logo-text">formation initiale</div>
 			<div id="slogan-text" class="art-logo-text">formation continue</div>
                    </div>
					
                </div>
				
                <div class="art-nav">
                	<div class="l"></div>
                	<div class="r"></div>
                	<ul class="art-menu">
                		<li>
                			<a href="index.php"><span class="l"></span><span class="r"></span><span class="t">Accueil</span></a>
                		</li>
                		<li>
                			<a href="formation.php"><span class="l"></span><span class="r"></span><span class="t">Formations</span></a>
                			<ul>
                				<li><a href="licence.php">Licence</a>
                					<ul>
                						<li><a href="stockages/licence/fm.pdf">Finance-Management</a></li>
                						<li><a href="stockages/licence/gi.pdf">Génie Informatique</a></li>
                						<li><a href="stockages/licence/GPMI.pdf">Gestion de Production et Management Industriel</a></li>
										<li><a href="stockages/licence/grh.pdf">Gestion des Ressources Humaines</a></li>
										<li><a href="stockages/licence/LBCL13.pdf">Business Et Climat d’Affaires</a></li>
										<li><a href="stockages/licence/LCARA13.pdf">Conception et Architecture des Réseaux Avancés</a></li>
										<li><a href="stockages/licence/LFI13.pdf">Finance Islamique</a></li>
										<li><a href="stockages/licence/LGIO.pdf">Gestion Informatisée des Organisations</a></li>
										<li><a href="stockages/licence/LIM13.pdf">Ingénierie et Maintenance Industrielle</a></li>
										<li><a href="stockages/licence/LMF13.pdf">Le Métier de Fiscaliste</a></li>
										<li><a href="stockages/licence/LPIEPA13.pdf">Ingénierie de l'Eau Potable et de l'Assainissement</a></li>
										<li><a href="stockages/licence/LPOEPME13.pdf">Pilotage des Organisations  et Entrepreneuriat des PME/PMI</a></li>
										<li><a href="stockages/licence/MC.pdf">Marketing et CRM</a></li>
										<li><a href="stockages/licence/mlq.pdf">Management de la Logistique et de la Qualité</a></li>
											</ul>
                				</li>
                				<li><a href="master.php">Master</a>
									<ul>
										<li><a href="stockages/master/MFM13.pdf">Management Financier</a></li>
										<li><a href="stockages/master/MMLQO13.pdf">Management Logistique et Qualité des Opérations </a></li>
											</ul>
                			</ul>
                		</li>		
                								<li>
                			<a href="#"><span class="l"></span><span class="r"></span><span class="t">Entreprises</span></a>
                		</li>
						<li>
                			<a href="#"><span class="l"></span><span class="r"></span><span class="t">A propos</span></a>
                		</li>
						<li>
                			<a href="contact.php"><span class="l"></span><span class="r"></span><span class="t">Contact</span></a>
                		</li>
                	</ul>
                </div>
                <div class="art-content-layout">
                    <div class="art-content-layout-row">
                        <div class="art-layout-cell art-content">
                            <div class="art-post">
                                <div class="art-post-body">
                            <div class="art-post-inner art-article">
                                                                                     <div class="art-postcontent">
                                                <!-- article-content -->
                                                
                                                
                                                
                                                <div class="cleared"></div>
                                                <div class="art-content-layout overview-table">
                                                	<div class="art-content-layout-row">
                                                		<div class="art-layout-cell">
                                                      <div class="overview-table-inner">
                                                	      
                                                       </div>
                                                		</div><!-- end cell -->
                                                		<div class="art-layout-cell">
                                                    <div class="overview-table-inner">
                                                		  
                                                				</div>
                                                		</div><!-- end cell -->
                                                		<div class="art-layout-cell">
                                                    <div class="overview-table-inner">
                                                		  
                                                              </div>
                                                		</div><!-- end cell -->
                                                	</div><!-- end row -->
                                                </div><!-- end table -->
                                                    
                                                <!-- /article-content -->
                                            </div>
                                            <div class="cleared"></div>
                            </div>
                            
                            		<div class="cleared"></div>
                                </div>
                            </div>
                            <div class="art-post">
                                <div class="art-post-body">
                            <div class="art-post-inner art-article">
                                            
                                            <div class="art-postcontent">
                                                <!-- article-content -->
                                             <center style="border:3px groove #FF9331">
											 <ul>
                						<li><a href="stockages/licence/fm.pdf">Finance-Management</a></li><br/>
                						<li><a href="stockages/licence/gi.pdf">Génie Informatique</a></li><br/>
                						<li><a href="stockages/licence/GPMI.pdf">Gestion de Production et Management Industriel</a></li><br/>
										<li><a href="stockages/licence/grh.pdf">Gestion des Ressources Humaines</a></li><br/>
										<li><a href="stockages/licence/LBCL13.pdf">Business Et Climat d’Affaires</a></li><br/>
										<li><a href="stockages/licence/LCARA13.pdf">Conception et Architecture des Réseaux Avancés</a></li><br/>
										<li><a href="stockages/licence/LFI13.pdf">Finance Islamique</a></li><br/>
										<li><a href="stockages/licence/LGIO.pdf">Gestion Informatisée des Organisations</a></li><br/>
										<li><a href="stockages/licence/LIM13.pdf">Ingénierie et Maintenance Industrielle</a></li><br/>
										<li><a href="stockages/licence/LMF13.pdf">Le Métier de Fiscaliste</a></li><br/>
										<li><a href="stockages/licence/LPIEPA13.pdf">Ingénierie de l'Eau Potable et de l'Assainissement</a></li><br/>
										<li><a href="stockages/licence/LPOEPME13.pdf">Pilotage des Organisations  et Entrepreneuriat des PME/PMI</a></li><br/>
										<li><a href="stockages/licence/MC.pdf">Marketing et CRM</a></li><br/>
										<li><a href="stockages/licence/mlq.pdf">Management de la Logistique et de la Qualité</a></li><br/>
											</ul>
                                                    </center>
                                                <!-- /article-content -->
                                            </div>
                                            <div class="cleared"></div>
                            </div>
                            
                            		<div class="cleared"></div>
                                </div>
                            </div>
                        </div>
                        <div class="art-layout-cell art-sidebar1">
                            <div class="art-vmenublock">
                                <div class="art-vmenublock-tl"></div>
                                <div class="art-vmenublock-tr"></div>
                                <div class="art-vmenublock-bl"></div>
                                <div class="art-vmenublock-br"></div>
                                <div class="art-vmenublock-tc"></div>
                                <div class="art-vmenublock-bc"></div>
                                <div class="art-vmenublock-cl"></div>
                                <div class="art-vmenublock-cr"></div>
                                <div class="art-vmenublock-cc"></div>
                                <div class="art-vmenublock-body">
                                            <div class="top_connect">
<form class="top_form" action="#" method="post">
<p>Connectez-vous...</p>
<p class="username_password">
	<img src=""  alt="" />
	<input type="text" name="login" value="Nom d'utilisateur" onFocus=" if ( this.value == 'Nom d\'utilisateur' ) { this.value = '' ; } " onBlur=" if ( this.value == ''  ) { this.value = 'Nom d\'utilisateur'; } "/>
</p>		
<p class="username_password">
	<img src=""  alt="" />
	<input type="password" name="password" value="Mot de passe" onFocus=" if ( this.value == 'Mot de passe' ) { this.value = '' ; } " onBlur=" if ( this.value == ''  ) { this.value = 'Mot de passe'; } "/>
</p>	
<div><p class="form_submit">
	<input type="submit" name="ok" id="ok" value="OK" >
</p>
<p>
<a href="inscription.php" >S'inscrire</a>
</p></div>
</form>
</div>
											<div class="art-vmenublockheader">
                                                <div class="l"></div>
                                                <div class="r"></div>
                                                 
												 <div class="t">Navigation</div>
                                            </div>
                                            <div class="art-vmenublockcontent">
                                                <div class="art-vmenublockcontent-body">
                                            <!-- block-content -->
                                                            <ul class="art-vmenu">
                                                            	<li>
                                                            		<a href="page.html?i1"><span class="l"></span><span class="r"></span><span class="t">Accueil</span></a>
                                                            	</li>
                                                            	<li>
                                                            		<a href="page.html?i2"><span class="l"></span><span class="r"></span><span class="t">Nouveautés</span></a>
                                                            				<ul>
                                                            			<li><a href="page.html?">Top 10</a></li>
                                                            		</ul>
                                                            	</li>
                                                            	<li class="active">
                                                            		<a class="active" href="page.html?i3"><span class="l"></span><span class="r"></span><span class="t">Menu Item</span></a>
                                                            		<ul class="active">
                                                            			<li><a href="page.html?i3s1">Subitem 1</a></li>
                                                            			<li><a href="page.html" class="active">Subitem 2</a></li>
                                                            			<li><a href="page.html?i3s3">Subitem 3</a></li>
                                                            		</ul>
                                                            	</li>
                                                            	<li>
                                                            		<a href="page.html?i4"><span class="l"></span><span class="r"></span><span class="t">Video</span></a>
                                                            	</li>
                                                            	<li>
                                                            		<a href="page.html?i5"><span class="l"></span><span class="r"></span><span class="t">Archive</span></a>
                                                            		<ul>
                                                            			<li><a href="page.html?i5s1">2008</a>
                                                            				<ul>
                                                            					<li><a href="page.html?i5s1s1">January</a></li>
                                                            					<li><a href="page.html?i5s1s2">February</a></li>
                                                            					<li><a href="page.html?i5s1s3">March</a></li>
                                                            				</ul>
                                                            			</li>
                                                            			<li><a href="page.html?i5s2">2007</a>
                                                            				<ul>
                                                            					<li><a href="page.html?i5s2s1">January</a></li>
                                                            					<li><a href="page.html?i5s2s2">February</a></li>
                                                            					<li><a href="page.html?i5s2s3">March</a></li>
                                                            				</ul>
                                                            			</li>
                                                            			<li><a href="page.html?i5s3">2006</a>
                                                            				<ul>
                                                            					<li><a href="page.html?i5s3s1">January</a></li>
                                                            					<li><a href="page.html?i5s3s2">February</a></li>
                                                            					<li><a href="page.html?i5s3s3">March</a></li>
                                                            				</ul>
                                                            			</li>
                                                            		</ul>
                                                            	</li>
                                                            	<li>
                                                            		<a href="page.html?i6"><span class="l"></span><span class="r"></span><span class="t">Forum</span></a>
                                                            	</li>
                                                            	<li>
                                                            		<a href="page.html?i7"><span class="l"></span><span class="r"></span><span class="t">A propos</span></a>
                                                            	</li>
                                                            	<li>
                                                            		<a href="page.html?i8"><span class="l"></span><span class="r"></span><span class="t">Contact</span></a>
                                                            	</li>
                                                            </ul>
                                            <!-- /block-content -->
                                            
                                            		<div class="cleared"></div>
                                                </div>
                                            </div>
                            		<div class="cleared"></div>
                                </div>
								<div>
<img src="images/facebook.png" style="padding-left:80px;padding-bottom:7px;">
</div>
                            </div>
                            <div class="art-block">
                                <div class="art-block-tl"></div>
                                <div class="art-block-tr"></div>
                                <div class="art-block-bl"></div>
                                <div class="art-block-br"></div>
                                <div class="art-block-tc"></div>
                                <div class="art-block-bc"></div>
                                <div class="art-block-cl"></div>
                                <div class="art-block-cr"></div>
                                <div class="art-block-cc"></div>
                                <div class="art-block-body">
                                            <div class="art-blockheader">
                                                <div class="l"></div>
                                                <div class="r"></div>
                                                 <div class="t">Newsletter</div>
                                            </div>
                                            <div class="art-blockcontent">
                                                <div class="art-blockcontent-body">
                                            <!-- block-content -->
                                                            <div><form method="get" id="newsletterform" action="javascript:void(0)">
                                                            <input type="text" value="" name="email" id="s" style="width: 95%;" />
                                                            <span class="art-button-wrapper">
                                                            	<span class="l"> </span>
                                                            	<span class="r"> </span>
                                                            	<input class="art-button" type="submit" name="search" value="Subscribe" />
                                                            </span>
                                                            
                                                            </form></div>
                                            <!-- /block-content -->
											
                                            
                                            		<div class="cleared"></div>
                                                </div>
                                            </div>
                            		<div class="cleared"></div>
                                </div>
                            </div>
                            <div class="art-block">
                                <div class="art-block-tl"></div>
                                <div class="art-block-tr"></div>
                                <div class="art-block-bl"></div>
                                <div class="art-block-br"></div>
                                <div class="art-block-tc"></div>
                                <div class="art-block-bc"></div>
                                <div class="art-block-cl"></div>
                                <div class="art-block-cr"></div>
                                <div class="art-block-cc"></div>
                                <div class="art-block-body">
                                            <div class="art-blockheader">
                                                <div class="l"></div>
                                                <div class="r"></div>
                                                 <div class="t">Highlights</div>
                                            </div>
                                            <div class="art-blockcontent">
                                                <div class="art-blockcontent-body">
                                            <!-- block-content -->
                                                            <div>
                                                                              <ul>
                                                                               <li><a href="#">Accueil</a></li>
                                                                               <li><a href="#">Overview</a></li>
                                                                               <li><a href="#">Demonstration</a></li>
                                                                               <li><a href="#">Telechargement</a></li>
                                                                               <li><a href="#">FAQ</a></li>
                                                                               <li><a href="#">Hyperlink</a></li>
                                                                               <li><a href="#" class="visited">liens visités</a></li>
                                                                               <li><a href="#" class="hover">Hovered link</a></li>
                                                                              </ul>
                                                                              
                                                                              <p><b>Jun 14, 2008</b><br />
                                                                              Aliquam sit amet felis. Mauris semper,
                                                                              velit semper laoreet dictum, quam
                                                                              diam dictum urna, nec placerat elit
                                                                              nisl in quam. Etiam augue pede,
                                                                              molestie eget, rhoncus at, convallis
                                                                              ut, eros. Aliquam pharetra.<br />
                                                                              <a href="javascript:void(0)">Read more...</a></p>
                                                            
                                                                              <p><b>Aug 24, 2008</b><br />
                                                                              Aliquam sit amet felis. Mauris semper,
                                                                              velit semper laoreet dictum, quam
                                                                              diam dictum urna, nec placerat elit
                                                                              nisl in quam. Etiam augue pede,
                                                                              molestie eget, rhoncus at, convallis
                                                                              ut, eros. Aliquam pharetra.<br />
                                                                              <a href="javascript:void(0)">Read more...</a></p>
                                                                              </div>
                                            <!-- /block-content -->
                                            
                                            		<div class="cleared"></div>
                                                </div>
                                            </div>
                            		<div class="cleared"></div>
                                </div>
                            </div>
                            <div class="art-block">
                                <div class="art-block-tl"></div>
                                <div class="art-block-tr"></div>
                                <div class="art-block-bl"></div>
                                <div class="art-block-br"></div>
                                <div class="art-block-tc"></div>
                                <div class="art-block-bc"></div>
                                <div class="art-block-cl"></div>
                                <div class="art-block-cr"></div>
                                <div class="art-block-cc"></div>
                                <div class="art-block-body">
                                            <div class="art-blockheader">
                                                <div class="l"></div>
                                                <div class="r"></div>
                                                 <div class="t">Informations de Contact</div>
                                            </div>
                                            <div class="art-blockcontent">
                                                <div class="art-blockcontent-body">
                                            <!-- block-content -->
                                                            <div>
                                                                 <iframe width="170" height="265" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://www.google.com/maps/embed?pb=!1m26!1m12!1m3!1d2830.6792405565643!2d-0.5989857848335919!3d44.807725229098686!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m11!3e2!4m5!1s0xd54d89b0defa981%3A0x8e9541340994921c!2sUniversit%C3%A9+de+Bordeaux+Campus+Talence%2C+351+Cours+de+la+Lib%C3%A9ration%2C+33400+Talence!3m2!1d44.807766799999996!2d-0.5967593!4m3!3m2!1d44.8075018!2d-0.5967616!5e0!3m2!1sfr!2sfr!4v1468363117176" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></iframe><br /><small><a href="https://www.google.fr/maps/dir/Universit%C3%A9+de+Bordeaux+Campus+Talence,+351+Cours+de+la+Lib%C3%A9ration,+33400+Talence/44.8075018,-0.5967616/@44.8077252,-0.5989858,17z/data=!3m1!4b1!4m9!4m8!1m5!1m1!1s0xd54d89b0defa981:0x8e9541340994921c!2m2!1d-0.5967593!2d44.8077668!1m0!3e2" style="color:#0000FF;text-align:left" target="_blank">Agrandir le plan</a></small>
                                                            <br />
                                                            <b>Université</b><br />
                                                            Sarra AOMARI<br />
                                                            Email: <a href="mailto:isna@univ.com">isna@univ.com</a><br />
                                                            <br />
                                                            Téléphone: +33 (0)5 40 00 60 00 <br />
                                                       
                                                            </div>
                                            <!-- /block-content -->
                                            
                                            		<div class="cleared"></div>
                                                </div>
                                            </div>
                            		<div class="cleared"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="cleared"></div><div class="art-footer">
                    <div class="art-footer-inner">
                        <a href="#" class="art-rss-tag-icon" title="RSS"></a>
                        <div class="art-footer-text">
                             <p><a href="index.php">Accueil</a> | <a href="formation.php">Formations</a>
                                | <a href="#">Entreprises</a> | <a href="#">Plan</a> | <a href="#">A propos</a> | <a href="contact.php">Contact</a><br />
                                Copyright &copy; 2014 ---. Tous Droits Réservés.</p>
                        </div>
                    </div>
                    <div class="art-footer-background"></div>
                </div>
        		<div class="cleared"></div>
            </div>
        </div>
        <div class="cleared"></div>
        
    </div>
    
</body>
</html>
