<?php 

try
{
 $bdd = new PDO('mysql:host=localhost;dbname=fpc', 'root', '');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}


	 
	       $req = $bdd->prepare('SELECT * FROM contact');				  
           $req->execute();
	
	 	?>
<center>		
		<table><header>LISTE DES Contacts</header>
	<tr >
	<td style="border: 3px maroon solid ">nom</td>
	<td style="border: 3px maroon solid">email</td>
	<td style="border: 3px maroon solid">message</td>
	</tr>    <?php
while ($donnees = $req->fetch())
{
    
	?> <tr>
	<td style="border: 3px maroon solid"> <?php  echo $donnees['nom']; ?>  </td>
	<td style="border: 3px maroon solid"><?php  echo $donnees['email']; ?> </td>
	<td style="border: 3px maroon solid; white-space:no wrap;"><?php  echo $donnees['message']; ?> </td>
	
	
	</tr> <?php

 	        
}
?>