<?php
#Les champs entre /**/ sont � compl�ter.

//connexion � mysql
$host="localhost"/*"ip de la base de donn�es"*/;
$account="root"/*"identifiant"*/;
$password=""/*"mot de passe"*/;
$dbname="newsletter"/*"nom de la base de donn�es"*/;
$connect=mysql_connect($host,$account,$password);
$db=mysql_select_db($dbname,$connect);

$sql="SELECT * FROM Nom de la table";     //r�cup�ration des donn�es
$result=mysql_query($sql,$connect);

$texte=$_POST['texte'];     //r�cup�ration du message dans le formulaire
$sujet=$texte;     //mise en forme du message
$entete="FROM: Adresse email de l'exp�diteur\n";
$entete .="MIME-Version: 1.0\n";
$entete .="Content-Type: multipart/alternative;boundary=\n";
$message = "\nThis is a multi-part message in MIME format.";
$message .="\n--\nContent-Type: text/html;charset=\"iso-8859-1\"\n\n";
$message .="$texte";
$message .="\n----\n end of the multi-part";

if($result === FALSE) { 
    die(mysql_error()); 
}
else
{
while($email=mysql_fetch_row($result))     //envoi du message � tous les emails de la base de donn�es
{
$res=mail($email[0],$sujet,$message,$entete);
}
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Newsletter</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

</body>
</html>
