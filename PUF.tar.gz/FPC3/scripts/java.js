$(function() {


  $("#envoyer").click($(function() {
  
  valid=true;
  
 

  
     if(($("#nom").val()==""))
	 {
	     $("#nom").css("border-color","red");
		 $("#nom").next("#erreur").text("nom vide");
		 valid=false;
	 }
	 else
	 {
	      $("#nom").css("border-color","green");
	 }
	 
	 
	 

	
	if(!($("#email").val().match(/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/)))
	 {
	     $("#email").css("border-color","red");
		 $("#email").next("#erreur").text("veuillez entrer un email valid");
		 valid=false;
	
	 }
	 else
	 {
	      $("#email").css("border-color","green");
		  $("#email").next("#erreur").text("");
	 }
	 
	 
	 if(($("#message").val()==""))
	 {
	     $("#message").css("border-color","red");
		 $("#message").next("#erreur").text("vous n avez saissisez le message");
		 valid=false;
	 }
	 else
	 {
	      $("#message").css("border-color","green");
		  $("#message").next("#erreur").text("");
	 }
	 
return false;
	// return valid;

}));



 


});