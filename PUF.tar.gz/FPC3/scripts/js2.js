$(function() {



 
$('#age').hide();

$('#date').blur(function() {
  
     
	 
	if(($("#date").val()!=""))
	 {
	      $("#date").next("#erreur").text("");
	      $("#date").css("border-color","green");
	 }
  
 
  
  }); 


  
 $('#cin').blur(function() {
  
       if(($("#cin").val()==""))
	 {
	     $("#cin").css("border-color","red");
		 $("#cin").next("#erreur").text("cin vide");
		 valid=false;
	 }
	 else
	 {
	 $("#cin").next("#erreur").text("");
	      $("#cin").css("border-color","green");
	 }
 
  
  }); 
  
  

 
  $('#nom').blur(function() {
  
     if(($("#nom").val()==""))
	 {
	     $("#nom").css("border-color","red");
		 $("#nom").next("#erreur").text("nom vide");
	 }
	 else
	 {
	  $("#nom").next("#erreur").text("");
	      $("#nom").css("border-color","green");
	 }
  
  });
  
    $('#prenom').blur(function() {
  
     if(($("#prenom").val()==""))
	 {
	     $("#prenom").css("border-color","red");
		 $("#prenom").next("#erreur").text("prenom vide");
	 }
	 else
	 {
	  $("#prenom").next("#erreur").text("");
	      $("#prenom").css("border-color","green");
	 }
  
  });
  
    $('#cne').blur(function() {
  
 

var text = $("#cne").val(), number;
number = parseInt(text);
text=number+'';

     if((text.length!=10) && $("#cne").val()!="")
	 {
	
	     $("#cne").css("border-color","red");
		 $("#cne").next("#erreur").text("cne incoret ce champ doit contenir 10 chiffres ");
	 }
	 else
	 {
	  $("#cne").next("#erreur").text("");
	      $("#cne").css("border-color","green");
	 }
  
  });
  
  
   $('#email').blur(function() {
  
     	
	if(!($("#email").val().match(/^[^0-9][_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/)))
	 {
	     $("#email").css("border-color","red");
		 $("#email").next("#erreur").text("veuillez entrer un email valid");
	 }
	 else
	 {
	      $("#email").css("border-color","green");
		  $("#email").next("#erreur").text("");
	 }
  
  });
  
  /*  
	 $('#ville').blur(function() {
	  
  
     if(($("#ville").val()!=0))
	 {
	     $("#lieu").val($("#ville").val());
		  $("#lieu").next("#erreur").text("");
	      $("#lieu").css("border-color","green");
	 }
	
  
  }); 
	
	*/
	  $('#lieu').blur(function() {
	
     if(($("#lieu").val()==""))
	 {
	
	     $("#lieu").css("border-color","red");
		 $("#lieu").next("#erreur").text("Saissisez votre lieu de naissance");
	 }
	 else
	 {
	  $("#lieu").next("#erreur").text("");
	      $("#lieu").css("border-color","green");
	 }
  
  });
  
 
  
  

	
	  $('#numero').blur(function() {
	  
	     var text2 = $("#numero").val(), number1;
	  var text3 = "1"+$("#numero").val();
number1 = parseInt(text3);
text1=number1+'';


     if(($("#numero").val()=="") || text1!=text3 || isNaN(text1)  )
	 {
	     $("#numero").css("border-color","red");
		 $("#numero").next("#erreur").text("ce numero n'est pas valide ");
	 }
	 else
	 {
	  $("#numero").next("#erreur").text("");
	      $("#numero").css("border-color","green");
	 }
  
  });
  
	
	
   $('#adresse').blur(function() {
  
 if(($("#adresse").val()==""))
	 {
	     $("#adresse").css("border-color","red");
		 $("#adresse").next("#erreur").text("vous n avez saissisez l adresse");
	 }
	 else
	 {
	      $("#adresse").css("border-color","green");
		  $("#adresse").next("#erreur").text("");
	 }
	 
  
  });
  
  




});