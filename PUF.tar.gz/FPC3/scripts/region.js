$(document).ready(function() {
 
                // au début on récupère les regions
                $.ajax({
                    url: 'liste.php', // lien vers la page de traitement sur le serveur
                    data: 'debut', // on envoie $_GET['debut'] pour signaler le début
                    dataType: 'json', // on veut un retour JSON
                    success: function(json) {
                        $.each(json, function(index, value) { // pour chaque noeud JSON
                            // on ajoute l option dans la liste
                            $('#regions').append('<option value="'+ index +'">'+ value +'</option>');
                        });
                    }
                });
 
                // si la liste des régions change
                $('#regions').on('change', function() {
                    var val = $(this).val(); // on récupère l'id de la région
 
                    if(val != '') {
                        $('#ville').empty(); // on vide la liste des villes
 
                        $.ajax({
                            url: 'liste.php', // lien vers la page de traitement sur le serveur
                            data: 'id='+ val, // on envoie $_GET['id'] l'id de la region
                            dataType: 'json', // on veut un retour JSON
                            success: function(json) {
                                $.each(json, function(index, value) { // on ajoute l option dans la liste
                                    $('#ville').append('<option value="'+ index +'">'+ value +'</option>');
                                });
                            }
                        });
                    }
                });
            });