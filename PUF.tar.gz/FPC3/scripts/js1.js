$(function() {


  $("#valider").click($(function() {
  
  valid=true;
  
  

var bool = $(':radio[name="sexe"]:checked').val()  || 0;
     if(!bool)
	 {
	   
		 $("#sexe1").text("     vous n'avez pas selectionné votre sexe");
		 valid=false;
	 }
	 else
	 {

	 $("#sexe1").text("");
	 }
  

   if(($("#date").val()==""))
	 {
	     $("#date").css("border-color","red");
		 $("#date").next("#erreur").text("date de naissance vide");
		 valid=false;
	 }
	 else
	 {
	 $("date").next("#erreur").text("");
	      $("#date").css("border-color","green");
	 }
  
  if(($("#lieu").val()==""))
	 {
	     $("#lieu").css("border-color","red");
		 $("#lieu").next("#erreur").text("lieu vide");
		 valid=false;
	 }
	 else
	 {
	 $("#lieu").next("#erreur").text("");
	      $("#lieu").css("border-color","green");
	 }
  
  
     var text2 = $("#numero").val(), number1;
	  var text3 = "1"+$("#numero").val();
number1 = parseInt(text3);
text1=number1+'';


     if(($("#numero").val()=="") || text1!=text3  || isNaN(text1)  )
	 {
	     $("#numero").css("border-color","red");
		 $("#numero").next("#erreur").text("ce numero n'est pas valide ");
	 }
	 else
	 {
	  $("#numero").next("#erreur").text("");
	      $("#numero").css("border-color","green");
	 }
 
 
     
  
       if(($("#cin").val()==""))
	 {
	     $("#cin").css("border-color","red");
		 $("#cin").next("#erreur").text("cin vide");
		 valid=false;
	 }
	 else
	 {
	 $("#cin").next("#erreur").text("");
	      $("#cin").css("border-color","green");
	 }
 
  

 
 
  
  
     if(($("#nom").val()==""))
	 {
	     $("#nom").css("border-color","red");
		 $("#nom").next("#erreur").text("nom vide");
		 valid=false;
	 }
	 else
	 {
	 $("#nom").next("#erreur").text("");
	      $("#nom").css("border-color","green");
	 }
	 
	  if(($("#prenom").val()==""))
	 {
	     $("#prenom").css("border-color","red");
		 $("#prenom").next("#erreur").text("prenom vide");
		 valid=false;
	 }
	 else
	 {
	  $("#prenom").next("#erreur").text("");
	      $("#prenom").css("border-color","green");
	 }
	 
	 
	 var text = $("#cne").val(), number;
number = parseInt(text);
text=number+'';

	 
	  if((text.length!=10) && $("#cne").val()!="" )
	 {
	     $("#cne").css("border-color","red");
		$("#cne").next("#erreur").text("cne incoret ce champ doit contenir 10 chiffres ");
		 valid=false;
	 }
	 else
	 {
	       $("#cne").next("#erreur").text("");
	       $("#cne").css("border-color","green");
	 }
	 
	 	
	if(!($("#email").val().match(/^[^0-9][_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/)))
	 {
	     $("#email").css("border-color","red");
		 $("#email").next("#erreur").text("veuillez entrer un email valid");
		 valid=false;
	 }
	 else
	 {

	      $("#email").css("border-color","green");
		  $("#email").next("#erreur").text("");
	 }
	 
	 
	 if(($("#adresse").val()==""))
	 {
	     $("#adresse").css("border-color","red");
		 $("#adresse").next("#erreur").text("vous n avez saissisez l adresse");
		 valid=false;
	 }
	 else
	 {
	      $("#adresse").css("border-color","green");
		  $("#adresse").next("#erreur").text("");
	 }
	 
	 
	 return valid;

}));



 


});