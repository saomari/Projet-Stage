$(function() {
 
 
$('#age').hide();
 

 
  $('#nom').blur(function() {
  
     if(($("#nom").val()==""))
	 {
	     $("#nom").css("border-color","red");
		 $("#nom").next("#erreur").text("nom vide");
	 }
	 else
	 {
	      $("#nom").css("border-color","green");
	 }
  
  });
  
   $('#email').blur(function() {

	if(!($("#email").val().match(/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/)))
	 {
	     $("#email").css("border-color","red");
		 $("#email").next("#erreur").text("veuillez entrer un email valid");
	 }
	 else
	 {
	      $("#email").css("border-color","green");
		  $("#email").next("#erreur").text("");
	 }
  
  });
  
    
   $('#message').blur(function() {
  
 if(($("#message").val()==""))
	 {
	     $("#message").css("border-color","red");
		 $("#message").next("#erreur").text("vous n avez pas saissisez le message");
	 }
	 else
	 {
	      $("#message").css("border-color","green");
		  $("#message").next("#erreur").text("");
	 }
	 
  
  });



});