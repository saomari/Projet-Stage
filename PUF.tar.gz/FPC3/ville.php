<?php 
if(!empty($_POST))
{
extract($_POST);
   if(!empty($age))
{
}
else
{
  $valid=true;
    $regex = '/^[^0-9][_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';
if (!preg_match($regex, $email)) {
       $valid=false;
       $erreuremail="votre email n'est pas valid";
} 
if(empty($nom) or empty($prenom) or empty($cne) or empty($lieu) or empty($adresse) or empty($numero) or $sexe)
   {
       $valid=false;
   }
   
   if($valid)
   {
      ?> <script> self.location.href='inscription2.php'; </script>	  <?php
   }
      }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="styleinscription.css" />
    <script type="text/javascript" language="Javascript" src="jquery.js" ></script>
	<script language="JavaScript">
// Code for validating the form
// Visit http://www.javascript-coder.com/html-form/javascript-form-validation.phtml
// for details
var frmvalidator  = new Validator("contact_form");
//remove the following two lines if you like error message box popups
frmvalidator.EnableOnPageErrorDisplaySingleBox();
frmvalidator.EnableMsgsTogether();

frmvalidator.addValidation("name","req","Please provide your name"); 
frmvalidator.addValidation("email","req","Please provide your email"); 
frmvalidator.addValidation("email","email","Please enter a valid email address"); 
</script>
<script language='JavaScript' type='text/javascript'>
function refreshCaptcha()
{
	var img = document.images['captchaimg'];
	img.src = img.src.substring(0,img.src.lastIndexOf("?"))+"?rand="+Math.random()*1000;
}
<script language="JavaScript" src="http://localhost/FPC/inscription/gen_validatorv31.js" type="text/javascript"></script>
</script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script> <!-- jQuery est inclus ! -->
       <script>
            $(document).ready(function() {
 
                // au début on récupère les regions
                $.ajax({
                    url: 'http://localhost/FPC/inscription/liste.php', // lien vers la page de traitement sur le serveur
                    data: 'debut', // on envoie $_GET['debut'] pour signaler le début
                    dataType: 'json', // on veut un retour JSON
                    success: function(json) {
                        $.each(json, function(index, value) { // pour chaque noeud JSON
                            // on ajoute l option dans la liste
                            $('#regions').append('<option value="'+ index +'">'+ value +'</option>');
                        });
                    }
                });
 
                // si la liste des régions change
                $('#regions').on('change', function() {
                    var val = $(this).val(); // on récupère l'id de la région
 
                    if(val != '') {
                        $('#ville').empty(); // on vide la liste des villes
 
                        $.ajax({
                            url: 'http://localhost/liste.php', // lien vers la page de traitement sur le serveur
                            data: 'id='+ val, // on envoie $_GET['id'] l'id de la region
                            dataType: 'json', // on veut un retour JSON
                            success: function(json) {
                                $.each(json, function(index, value) { // on ajoute l option dans la liste
                                    $('#ville').append('<option value="'+ index +'">'+ value +'</option>');
                                });
                            }
                        });
                    }
                });
            });
 
       </script>
	<?php if(!empty($_POST)) { ?>
    <script src="js1.js"></script>
	<?php } ?>
	<script src="js2.js"></script>
</head>
<body>

<?php if(isset($erreur)) echo $erreur; ?>
      <form method="post" action="inscription.php" >
	  
	       <label for="cne" > CNE :</label> <br/>
			<input type="text" name="cne" id="cne" value="<?php if(isset($cne)) echo $cne; ?>"  /> 
			<span id="erreur" ></span> <br/><br/><br/>
	  
	  <input type="text" name="age" id="age"  /> 
	  
			<label for="nom" > Nom :</label> <label for="prenom" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Prenom : </label>   <br/>
			<input type="text" name="nom" id="nom" value="<?php if(isset($nom)) echo $nom; ?>"  /> 
			<span id="erreur" ></span> 
			
			
			<input type="text" name="prenom" id="nom" value="<?php if(isset($prenom)) echo $prenom; ?>"  /> 
			<span id="erreur" ></span> <br/><br/><br/>
			
			
			 Date de Naissance : <label for="lieu" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Lieu de Naissance :</label> 
		<br/>	<select name="jour">
			<?php
			   for($i=1;$i<=31;$i++) {
			?>
                      <option value="<?php echo $i; ?> ">  <?php echo $i; ?> </option>  
	     <?php } ?>
          </select>  
		  <select name="mois">
			
                     <option value="1">  JANVIER </option> 
<option value="2">  FEVRIER </option>  
<option value="3">  MARS </option>  
<option value="4">  AVRIL </option>  
<option value="5">  MAI </option>  
<option value="6">  JUIN </option>  
<option value="7">  JUILLET </option> 
<option value="8">  AOUT </option>  
<option value="9">  SEPTEMBRE </option>  
<option value="10">  OCTOBRE </option>  
<option value="11">  NOVEMBRE </option>  
<option value="12">  DECEMBRE </option>  
					  
	    
          </select>  
		  
		  <select name="annee">
			<?php
			   for($i=2014;$i>=1;$i--) {
			?>
                      <option value="<?php echo $i ;?> ">  <?php echo $i ; ?> </option>  
	     <?php } ?>
          </select> 
		  
		  
		  
			
			<select id="regions" name="regions">
        <option value="">les régions</option>
    </select>
 
    <select id="ville" name="ville">
        <option value=""> les villes</option>
    </select> <br/><br/><br/>
			
			<p> Sexe: <input type="radio" name="sexe" value="M" id="M" /> <label for="M">Masculin</label>
            <input type="radio" name="sexe" value="F" id="F" /> <label for="F">Feminin</label> </p>	
			
			<label for="email" > Votre Email :</label> <br/>
			<input type="text" name="email" id="email" value="<?php if(isset($email)) echo $email; ?>" />  
			<span id="erreur" ></span> <br/><br/><br/>
			<p>
<img src="http://localhost/FPC/inscription/captcha_code_file.php?rand=<?php echo rand(); ?>" id='captchaimg' width="120px" height="40px"><br>
<label for='message'>Entrez le code suivant :</label><br>
<input id="6_letters_code" name="6_letters_code" type="text"><br>
<small>Problèleme? Cliquez <a href='javascript: refreshCaptcha();'>ici</a> Pour actualiser</small>
</p>
			
			<label for="numero" > Numero du telephone :</label> <br/>
		     <input type="text" name="numero" id="numero" value="<?php if(isset($numero)) echo $numero; ?> " />  
			<span id="erreur" ></span> <br/><br/><br/>
			
			
			<label for="adresse" > Adresse :</label> <br/>
			<textarea  name="adresse" id="adresse" value="" ><?php if(isset($adresse)) echo $adresse; ?></textarea> 
			<span id="erreur" ></span> <br/><br/><br/>
			
			
			
			
			<input type="submit" value="Envoyer" id="envoyer" />
			
      </form>
	</body>
    </html>  