<?php
   try
{
 $bdd = new PDO('mysql:host=localhost;dbname=fpc', 'root', '');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}

if(isset($_POST['ok'])  and  isset($_POST['password']) and isset($_POST['login']))
{

extract($_POST);
$req = $bdd->prepare('SELECT * FROM candidat where login=? and mdp=?');
$req->execute(array($login,$password));
if(isset($_SESSION['login1']))
 unset($_SESSION['login1']);
 if(isset($_SESSION['mdp']))
 unset($_SESSION['mdp']);
 
 $_SESSION['login1']=$login;
$_SESSION['mdp1']=$password;

$b=true;
while ($donnees = $req->fetch())
{
    if($donnees['login']==$login and $donnees['mdp']==$password)  
     {
	
	       $b=false;
		   $req->closeCursor();
		   ?> <script>  self.location.href='candidat.php'; </script> <?php
	 }    
}
if($b==true)
{

     $req = $bdd->prepare('SELECT * FROM administrateur where login=? and mdp=?');
     $req->execute(array($login,$password));
while ($donnees = $req->fetch())
{
    if($donnees['login']==$login and $donnees['mdp']==$password)  
     {
	       $b=false;
		   $req->closeCursor();
		   ?> <script>  self.location.href='admin.php'; </script> <?php
	 }  	 
}
}

if($b==true)
{
   $req->closeCursor();
   ?> <script>  alert("vous avez saissiser un login ou un mot de passe incorect"); </script> <?php
}


}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.Style1 {
	color: #000000;
	font-size: 36px;
	font-weight: bold;
}
body {
	background-image:  url(fond.jpg);
}
-->
</style>
</head>

<body>
<p align="center">&nbsp;</p>
<p align="center"><span class="Style1">Newsletter</span></p>
<p align="center"><br>
</p>
<form name="form1" method="post" action="newsletter.php">
  <p align="center"><strong>Message au format HTML : </strong></p>
  <p align="center">
    <textarea name="texte" cols="100" rows="20" id="texte"></textarea>
  </p>
  <p align="center">
    <input type="submit" name="Submit" value="Envoyer">
</p>
</form>

</body>
</html>
